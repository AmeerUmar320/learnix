import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../blocs/group/group_bloc.dart';
import '../blocs/group/group_event.dart';
import '../blocs/group/group_state.dart';
import '../models/group_model.dart';

class GroupChatScreen extends StatefulWidget {
  final int groupId;
  const GroupChatScreen({super.key, required this.groupId});
  @override
  State<GroupChatScreen> createState() => _GroupChatScreenState();
}

class _GroupChatScreenState extends State<GroupChatScreen> {
  @override
  void initState() {
    super.initState();
    context.read<GroupBloc>().add(FetchGroupById(widget.groupId));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0E1213),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0E1213),
        elevation: 0,
        title: BlocBuilder<GroupBloc, GroupState>(
          builder: (context, state) {
            if (state is GroupLoaded) {
              final group = state.group;
              return Row(
                children: [
                  CircleAvatar(
                    backgroundImage: group.profilePictureUrl != null && group.profilePictureUrl!.isNotEmpty
                        ? NetworkImage('http://192.168.100.28:5241${group.profilePictureUrl!}')
                        : const AssetImage('assets/profiles/profile_7.jpg') as ImageProvider,
                    radius: 16,
                  ),
                  const SizedBox(width: 8),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(group.name, style: const TextStyle(color: Colors.white, fontSize: 16)),
                      Text(
                        '${group.members?.length ?? 0} members',
                        style: const TextStyle(color: Colors.white54, fontSize: 12),
                      ),
                    ],
                  ),
                ],
              );
            }
            return const Text('Group Chat', style: TextStyle(color: Colors.white));
          },
        ),
        leading: const BackButton(color: Colors.white),
      ),
      body: BlocBuilder<GroupBloc, GroupState>(
        builder: (context, state) {
          if (state is GroupLoading) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is GroupLoaded) {
            final group = state.group;
            // Replace this section with your real chat implementation
            return Center(
              child: Text(
                "Chat for group: ${group.name}\n(${group.members?.length ?? 0} members)",
                style: const TextStyle(color: Colors.white),
                textAlign: TextAlign.center,
              ),
            );
          } else if (state is GroupFailure) {
            return Center(child: Text('Error: ${state.error}', style: const TextStyle(color: Colors.red)));
          }
          return const SizedBox.shrink();
        },
      ),
    );
  }
}
