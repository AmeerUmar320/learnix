class GroupModel {
  final int id;
  final String name;
  final String? description;
  final String? profilePictureUrl;
  final List<dynamic>? members; // Update to correct user model if desired

  GroupModel({
    required this.id,
    required this.name,
    this.description,
    this.profilePictureUrl,
    this.members,
  });

  factory GroupModel.fromJson(Map<String, dynamic> json) {
    return GroupModel(
      id: json['id'],
      name: json['name'],
      description: json['description'],
      profilePictureUrl: json['profilePictureUrl'],
      members: json['members'],
    );
  }
}
